package com.fiverr.app;

import androidx.core.content.FileProvider;

public class GenericFileProvider extends FileProvider {}
