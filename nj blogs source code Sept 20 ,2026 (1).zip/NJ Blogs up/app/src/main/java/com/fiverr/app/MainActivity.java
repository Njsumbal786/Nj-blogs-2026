package com.fiverr.app;

import static com.fiverr.app.Config.ACTIVATE_PROGRESS_BAR;
import static com.fiverr.app.Config.AUTO_DOWNLOAD_FILES;
import static com.fiverr.app.Config.DISABLE_DARK_MODE;
import static com.fiverr.app.Config.ENABLE_PULL_REFRESH;
import static com.fiverr.app.Config.ENABLE_SWIPE_NAVIGATE;
import static com.fiverr.app.Config.ENABLE_ZOOM;
import static com.fiverr.app.Config.EXIT_APP_DIALOG;
import static com.fiverr.app.Config.HIDE_HORIZONTAL_SCROLLBAR;
import static com.fiverr.app.Config.HIDE_NAVIGATION_BAR_IN_LANDSCAPE;
import static com.fiverr.app.Config.HIDE_VERTICAL_SCROLLBAR;
import static com.fiverr.app.Config.MAX_TEXT_ZOOM;
import static com.fiverr.app.Config.PREVENT_SLEEP;
import static com.fiverr.app.Config.REMAIN_SPLASH_OPTION;
import static com.fiverr.app.Config.SPECIAL_LINK_HANDLING_OPTIONS;
import static com.fiverr.app.Config.SPLASH_SCREEN_ACTIVATED;
import static com.fiverr.app.Config.downloadableExtension;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.BitmapDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.preference.PreferenceManager;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.InputType;
import android.text.TextUtils;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.GeolocationPermissions;
import android.webkit.HttpAuthHandler;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.SslErrorHandler;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.browser.customtabs.CustomTabsIntent;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.fiverr.app.deeplinking.Deeplinking;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "NJBlogs";
    private static final String INDEX_FILE = "file:///android_asset/local-html/index.html";
    private static final int FCR = 1;
    private static final int CODE_AUDIO_CHOOSER = 5678;
    public static final int MULTIPLE_PERMISSIONS = 10;
    public final int REQUEST_PERMISSION_STORAGE_CAMERA = 354;

    private CustomWebView webView;
    private SwipeRefreshLayout mySwipeRefreshLayout;
    public ProgressBar progressBar;
    private View offlineLayout;
    private RelativeLayout windowContainer;
    private RelativeLayout mContainer;
    private WebView mWebviewPop;

    private SharedPreferences preferences;
    private ValueCallback<Uri[]> mUMA;
    private String mCM, mVM;
    private String deepLinkingURL;
    private boolean isErrorPageLoaded = false;
    public String uuid = "";
    public static Context mContext;
    private static boolean connectedNow = false;
    private long SPLASH_SCREEN_ACTIVE = 0;

    WebChromeClient.FileChooserParams fileChooserParams;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        mContext = this;

        uuid = Settings.System.getString(super.getContentResolver(), Settings.Secure.ANDROID_ID);
        preferences = PreferenceManager.getDefaultSharedPreferences(this);

        if (isRooted() && Config.BLOCK_ROOTED_DEVICES) {
            showRootedErrorMessage();
        }

        if (HIDE_NAVIGATION_BAR_IN_LANDSCAPE && getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) {
            View decorView = getWindow().getDecorView();
            decorView.setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_IMMERSIVE
                            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_FULLSCREEN);
        }

        if (DISABLE_DARK_MODE && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (Config.blackStatusBarText) {
                getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
            }
        }

        if (PREVENT_SLEEP) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        } else {
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }

        super.onCreate(savedInstanceState);

        if (SPLASH_SCREEN_ACTIVATED && (REMAIN_SPLASH_OPTION || Config.SPLASH_FADE_OUT != 0)) {
            SPLASH_SCREEN_ACTIVE = System.currentTimeMillis();
            startActivity(new Intent(getApplicationContext(), SplashScreen.class));
            if (!REMAIN_SPLASH_OPTION || Config.SPLASH_TIMEOUT > 0) {
                new Handler(Looper.getMainLooper()).postDelayed(() -> {
                    if (SPLASH_SCREEN_ACTIVE != 0 && (SplashScreen.getInstance() != null)) {
                        SplashScreen.getInstance().animateFinish();
                        SPLASH_SCREEN_ACTIVE = 0;
                    }
                }, Config.SPLASH_TIMEOUT);
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            getWindow().getAttributes().layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS;
            Bitmap bitmap = Bitmap.createBitmap(24, 24, Bitmap.Config.ARGB_8888);
            bitmap.eraseColor(getResources().getColor(R.color.colorPrimaryDark));
            BitmapDrawable bitmapDrawable = new BitmapDrawable(getResources(), bitmap);
            getWindow().setBackgroundDrawable(bitmapDrawable);
        }

        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            }
            return insets;
        });

        if (Config.TRANSPARENT_STATUS_BAR) {
            View mainView = findViewById(R.id.main);
            mainView.setFitsSystemWindows(false);
            WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        }

        if (savedInstanceState == null) {
            AlertManager.appLaunched(this);
        }

        webView = findViewById(R.id.webView);
        mContainer = findViewById(R.id.web_container);
        windowContainer = findViewById(R.id.window_container);

        if (Config.HARDWARE_ACCELERATION) {
            webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        } else {
            webView.setLayerType(View.LAYER_TYPE_NONE, null);
        }

        webView.getSettings().setMediaPlaybackRequiresUserGesture(false);
        webView.setGestureDetector(new GestureDetector(this, new CustomeGestureDetector()));

        if (BuildConfig.IS_DEBUG_MODE) {
            WebView.setWebContentsDebuggingEnabled(true);
        }

        mySwipeRefreshLayout = findViewById(R.id.swipeContainer);
        if (!ENABLE_PULL_REFRESH) {
            mySwipeRefreshLayout.setEnabled(false);
        }

        if (HIDE_VERTICAL_SCROLLBAR) {
            webView.setVerticalScrollBarEnabled(false);
        }
        if (HIDE_HORIZONTAL_SCROLLBAR) {
            webView.setHorizontalScrollBarEnabled(false);
        }

        mySwipeRefreshLayout.setOnRefreshListener(() -> {
            if (ENABLE_PULL_REFRESH) {
                webView.reload();
            }
            mySwipeRefreshLayout.setRefreshing(false);
        });

        offlineLayout = findViewById(R.id.offline_layout);
        setOfflineScreenBackgroundColor();

        findViewById(android.R.id.content).setBackgroundColor(getResources().getColor(R.color.launchLoadingSignBackground));
        progressBar = findViewById(R.id.progressBar);
        progressBar.getIndeterminateDrawable().setColorFilter(getResources().getColor(R.color.colorAccent), PorterDuff.Mode.MULTIPLY);

        final Button tryAgainButton = findViewById(R.id.try_again_button);
        tryAgainButton.setOnClickListener(view -> {
            webView.setVisibility(View.GONE);
            loadMainUrl();
        });

        webView.setWebViewClient(new MyWebViewClient());
        webView.getSettings().setSupportMultipleWindows(true);
        webView.getSettings().setUseWideViewPort(true);

        final String appName;
        String appName1;
        try {
            appName1 = getApplicationInfo().loadLabel(getPackageManager()).toString();
        } catch (Exception e) {
            appName1 = webView.getTitle();
        }
        appName = appName1 != null ? appName1 : "NJ Blogs";

        webView.setWebChromeClient(new MyWebChromeClient(appName));

        webView.setDownloadListener((url, userAgent, contentDisposition, mimetype, contentLength) -> {
            try {
                if (AUTO_DOWNLOAD_FILES) {
                    downloadFile(url);
                } else {
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData(Uri.parse(url));
                    startActivity(i);
                }
            } catch (Exception e) {
                toast("No activity to handle the downloaded file.");
            }
        });

        final WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);
        webSettings.setAllowFileAccess(true);
        webSettings.setUseWideViewPort(true);
        webSettings.setLoadWithOverviewMode(true);
        webSettings.setAllowContentAccess(true);
        webSettings.setGeolocationEnabled(true);
        webSettings.setSupportZoom(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            webSettings.setSafeBrowsingEnabled(true);
        }
        webSettings.setJavaScriptCanOpenWindowsAutomatically(true);
        if (ENABLE_ZOOM) {
            webSettings.setBuiltInZoomControls(true);
            webSettings.setDisplayZoomControls(false);
        } else {
            webSettings.setBuiltInZoomControls(false);
        }

        if (Config.CLEAR_CACHE_ON_STARTUP) {
            webSettings.setCacheMode(WebSettings.LOAD_NO_CACHE);
            webView.clearCache(true);
            CookieManager.getInstance().removeAllCookies(null);
            CookieManager.getInstance().flush();
        } else {
            webSettings.setCacheMode(WebSettings.LOAD_DEFAULT);
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);
        }

        webSettings.setAllowUniversalAccessFromFileURLs(false);
        webSettings.setAllowFileAccessFromFileURLs(false);
        webSettings.setDatabaseEnabled(true);
        webSettings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);

        if (MAX_TEXT_ZOOM > 0) {
            float systemTextZoom = getResources().getConfiguration().fontScale * 100;
            if (systemTextZoom > MAX_TEXT_ZOOM) {
                webView.getSettings().setTextZoom(MAX_TEXT_ZOOM);
            }
        }

        applyOrientationSettings(webSettings);

        if (!Config.USER_AGENT.isEmpty()) {
            webSettings.setUserAgentString(Config.USER_AGENT);
        }

        handleIntentUrl(getIntent());

        if (Config.USE_LOCAL_HTML_FOLDER) {
            loadLocal(INDEX_FILE);
        } else if (isConnectedNetwork()) {
            loadMainUrl();
            connectedNow = true;
        } else {
            checkInternetConnection();
        }
    }

    private void applyOrientationSettings(WebSettings webSettings) {
        if (webSettings.getUserAgentString().contains("Mobile")) {
            if ("auto".equals(Config.PHONE_ORIENTATION)) {
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_USER);
            } else if ("portrait".equals(Config.PHONE_ORIENTATION)) {
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
            } else if ("landscape".equals(Config.PHONE_ORIENTATION)) {
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
            }
        } else {
            if ("auto".equals(Config.TABLET_ORIENTATION)) {
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_USER);
            } else if ("portrait".equals(Config.TABLET_ORIENTATION)) {
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
            } else if ("landscape".equals(Config.TABLET_ORIENTATION)) {
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
            }
        }
    }

    private void handleIntentUrl(Intent intent) {
        if (intent != null && intent.getData() != null) {
            deepLinkingURL = Deeplinking.constructDeeplink(intent);
        }
        if (intent != null && intent.getExtras() != null) {
            String openurl = intent.getExtras().getString("openURL");
            if (openurl != null) {
                openInExternalBrowser(openurl);
            }
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntentUrl(intent);
        if (deepLinkingURL != null && !deepLinkingURL.isEmpty()) {
            loadMainUrl();
        }
    }

    private void loadMainUrl() {
        if (!isConnectedNetwork()) {
            if (Config.FALLBACK_USE_LOCAL_HTML_FOLDER_IF_OFFLINE) {
                loadLocal(INDEX_FILE);
                isErrorPageLoaded = true;
            } else {
                webView.setVisibility(View.GONE);
                offlineLayout.setVisibility(View.VISIBLE);
            }
            return;
        }

        offlineLayout.setVisibility(View.GONE);
        webView.setVisibility(View.VISIBLE);

        if (Config.IS_DEEP_LINKING_ENABLED && deepLinkingURL != null && !deepLinkingURL.isEmpty()) {
            if (Config.IS_CUSTOM_SCHEME_ENABLED && Deeplinking.isValidSchemeURL(deepLinkingURL)) {
                webView.loadUrl(Deeplinking.convertSchemeToHttps(deepLinkingURL));
                return;
            } else if (URLUtil.isValidUrl(deepLinkingURL)) {
                webView.loadUrl(deepLinkingURL);
                return;
            }
        }

        String language = "";
        if (Config.APPEND_LANG_CODE) {
            language = Locale.getDefault().getLanguage().toUpperCase();
            language = "?webview_language=" + language;
        }
        String urlToLoad = Config.HOME_URL + language;
        if (Config.UUID_ENHANCE_WEBVIEW_URL) {
            urlToLoad += (urlToLoad.contains("?") ? "&" : "?") + "uuid=" + uuid;
        }

        if (Config.USE_LOCAL_HTML_FOLDER) {
            loadLocal(INDEX_FILE);
        } else {
            webView.loadUrl(urlToLoad);
        }
    }

    private void loadLocal(String path) {
        webView.loadUrl(path);
        webView.setVisibility(View.VISIBLE);
        offlineLayout.setVisibility(View.GONE);
    }

    private void checkInternetConnection() {
        if (!isConnectedNetwork()) {
            if (Config.FALLBACK_USE_LOCAL_HTML_FOLDER_IF_OFFLINE) {
                loadLocal(INDEX_FILE);
                isErrorPageLoaded = true;
            } else {
                webView.setVisibility(View.GONE);
                offlineLayout.setVisibility(View.VISIBLE);
            }
        } else {
            offlineLayout.setVisibility(View.GONE);
            webView.setVisibility(View.VISIBLE);
        }
    }

    public boolean isConnectedNetwork() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm != null) {
            NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
            return activeNetwork != null && activeNetwork.isConnectedOrConnecting();
        }
        return false;
    }

    private boolean URLisExternal(String url) {
        if (url == null) return false;
        try {
            String host = Uri.parse(url).getHost();
            if (host != null && (host.contains(Config.HOST) || url.contains(Config.HOST))) {
                return false;
            }
        } catch (Exception ignored) {
        }
        return true;
    }

    public boolean shouldAlwaysOpenInInappTab(String URL) {
        for (String s : Config.ALWAYS_OPEN_IN_INAPP_TAB) {
            if (!s.isEmpty() && URL.startsWith(s)) {
                return true;
            }
        }
        return false;
    }

    void openInInappTab(String URL) {
        try {
            CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();
            builder.setToolbarColor(getResources().getColor(R.color.colorPrimaryDark));
            CustomTabsIntent customTabsIntent = builder.build();
            CookieManager cookieManager = CookieManager.getInstance();
            String allCookies = cookieManager.getCookie(URL);
            if (allCookies != null) {
                String[] cookieList = allCookies.split(";");
                for (String cookie : cookieList) {
                    customTabsIntent.intent.putExtra("android.webkit.CookieManager.COOKIE", cookie.trim());
                }
            }
            customTabsIntent.launchUrl(this, Uri.parse(URL));
            webView.stopLoading();
        } catch (Exception e) {
            openInExternalBrowser(URL);
        }
    }

    void openInNewBrowser(String url) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(i);
        } catch (Exception e) {
            toast("No application found to handle URL.");
        }
    }

    private void openInExternalBrowser(String launchUrl) {
        openInNewBrowser(launchUrl);
    }

    private void openFilePicker(WebChromeClient.FileChooserParams params) {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            File photoFile = null;
            try {
                photoFile = createImageFile();
            } catch (IOException ex) {
                if (BuildConfig.IS_DEBUG_MODE) Log.d(TAG, "Image file creation failed", ex);
            }
            if (photoFile != null) {
                mCM = "file:" + photoFile.getAbsolutePath();
                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT,
                        FileProvider.getUriForFile(this, getPackageName() + ".provider", photoFile));
            } else {
                takePictureIntent = null;
            }
        }

        Intent takeVideoIntent = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
        if (takeVideoIntent.resolveActivity(getPackageManager()) != null) {
            File videoFile = null;
            try {
                videoFile = createVideoFile();
            } catch (IOException ex) {
                if (BuildConfig.IS_DEBUG_MODE) Log.d(TAG, "Video file creation failed", ex);
            }
            if (videoFile != null) {
                mVM = "file:" + videoFile.getAbsolutePath();
                takeVideoIntent.putExtra(MediaStore.EXTRA_OUTPUT,
                        FileProvider.getUriForFile(this, getPackageName() + ".provider", videoFile));
            } else {
                takeVideoIntent = null;
            }
        }

        Intent contentSelectionIntent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        contentSelectionIntent.addCategory(Intent.CATEGORY_OPENABLE);
        contentSelectionIntent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        contentSelectionIntent.setType("*/*");
        String[] mimeTypes = {"text/csv", "text/comma-separated-values", "application/pdf", "image/*", "video/*"};
        contentSelectionIntent.putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes);

        Intent[] intentArray;
        if (takePictureIntent != null && takeVideoIntent != null) {
            intentArray = new Intent[]{takePictureIntent, takeVideoIntent};
        } else if (takePictureIntent != null) {
            intentArray = new Intent[]{takePictureIntent};
        } else if (takeVideoIntent != null) {
            intentArray = new Intent[]{takeVideoIntent};
        } else {
            intentArray = new Intent[0];
        }

        Intent chooserIntent = new Intent(Intent.ACTION_CHOOSER);
        chooserIntent.putExtra(Intent.EXTRA_INTENT, contentSelectionIntent);
        chooserIntent.putExtra(Intent.EXTRA_TITLE, "Select File");
        if (intentArray.length > 0) {
            chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, intentArray);
        }
        startActivityForResult(chooserIntent, FCR);
    }

    private File createImageFile() throws IOException {
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        File mediaStorageDir = getCacheDir();
        if (!mediaStorageDir.exists()) {
            mediaStorageDir.mkdirs();
        }
        return File.createTempFile(imageFileName, ".jpg", mediaStorageDir);
    }

    private File createVideoFile() throws IOException {
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        String videoFileName = "VID_" + timeStamp + "_";
        File mediaStorageDir = getCacheDir();
        if (!mediaStorageDir.exists()) {
            mediaStorageDir.mkdirs();
        }
        return File.createTempFile(videoFileName, ".mp4", mediaStorageDir);
    }

    private void downloadFile(String url) {
        try {
            String fileName = getFileNameFromURL(url);
            Toast.makeText(this, "Downloading file...", Toast.LENGTH_SHORT).show();
            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
            String cookie = CookieManager.getInstance().getCookie(url);
            request.addRequestHeader("Cookie", cookie);
            request.allowScanningByMediaScanner();
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName);
            DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            if (dm != null) {
                dm.enqueue(request);
            }
        } catch (Exception e) {
            e.printStackTrace();
            toast("Download failed: " + e.getMessage());
        }
    }

    public static String getFileNameFromURL(String url) {
        if (url == null) return "downloaded_file";
        try {
            String name = URLUtil.guessFileName(url, null, null);
            if (!TextUtils.isEmpty(name)) return name;
        } catch (Exception ignored) {
        }
        return "download_" + System.currentTimeMillis();
    }

    private void customCSS() {
        try {
            InputStream inputStream = getAssets().open("custom.css");
            byte[] cssbuffer = new byte[inputStream.available()];
            inputStream.read(cssbuffer);
            inputStream.close();

            String encodedcss = Base64.encodeToString(cssbuffer, Base64.NO_WRAP);
            if (!TextUtils.isEmpty(encodedcss)) {
                webView.loadUrl("javascript:(function() {" +
                        "var parent = document.getElementsByTagName('head').item(0);" +
                        "var style = document.createElement('style');" +
                        "style.type = 'text/css';" +
                        "style.innerHTML = window.atob('" + encodedcss + "');" +
                        "parent.appendChild(style)" +
                        "})()");
            }
        } catch (Exception ignored) {
        }
    }

    private void customJavaScript() {
        try {
            InputStream inputStream = getAssets().open("custom.js");
            byte[] jsBuffer = new byte[inputStream.available()];
            inputStream.read(jsBuffer);
            inputStream.close();

            String encodedJs = Base64.encodeToString(jsBuffer, Base64.NO_WRAP);
            if (!TextUtils.isEmpty(encodedJs)) {
                webView.loadUrl("javascript:(function() {" +
                        "var customJsCode = window.atob('" + encodedJs + "');" +
                        "var executeCustomJs = new Function(customJsCode);" +
                        "executeCustomJs();" +
                        "})()");
            }
        } catch (Exception ignored) {
        }
    }

    public void ExitDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(getResources().getString(R.string.exit_app_dialog))
                .setCancelable(false)
                .setPositiveButton(getResources().getString(R.string.yes), (dialog, id) -> finish())
                .setNegativeButton(getResources().getString(R.string.no), (dialog, id) -> dialog.cancel());

        AlertDialog alert = builder.create();
        alert.setOnShowListener(dialogInterface -> {
            alert.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(Color.RED);
            alert.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(Color.BLACK);
        });
        alert.show();
    }

    public void ClosePopupWindow(View view) {
        if (progressBar != null) progressBar.setVisibility(View.GONE);
        if (mContainer != null) mContainer.removeAllViews();
        if (windowContainer != null) windowContainer.setVisibility(View.GONE);
        if (mWebviewPop != null) {
            mWebviewPop.destroy();
            mWebviewPop = null;
        }
    }

    private void setOfflineScreenBackgroundColor() {
        if (offlineLayout != null && offlineLayout.getBackground() != null) {
            try {
                offlineLayout.getBackground().setColorFilter(Color.parseColor(Config.OFFLINE_SCREEN_BACKGROUND_COLOR), PorterDuff.Mode.DARKEN);
            } catch (Exception ignored) {
            }
        }
    }

    public static boolean isRooted() {
        String buildTags = Build.TAGS;
        if (buildTags != null && buildTags.contains("test-keys")) {
            return true;
        }
        try {
            File file = new File("/system/app/Superuser.apk");
            if (file.exists()) return true;
        } catch (Exception ignored) {
        }
        return !canExecuteCommand("su") && findBinary("su");
    }

    private void showRootedErrorMessage() {
        new AlertDialog.Builder(this)
                .setTitle("Security Error")
                .setMessage("This app cannot run on a rooted device for security reasons.")
                .setPositiveButton("Exit", (dialog, which) -> finish())
                .setCancelable(false)
                .show();
    }

    public static boolean findBinary(String binaryName) {
        String[] places = {"/sbin/", "/system/bin/", "/system/xbin/", "/data/local/xbin/", "/data/local/bin/", "/system/sd/xbin/", "/system/bin/failsafe/", "/data/local/"};
        for (String where : places) {
            if (new File(where + binaryName).exists()) {
                return true;
            }
        }
        return false;
    }

    private static boolean canExecuteCommand(String command) {
        try {
            Runtime.getRuntime().exec(command);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);

        if (requestCode == FCR) {
            Uri[] results = null;
            if (resultCode == Activity.RESULT_OK) {
                if (mUMA == null) return;
                if (intent == null || intent.getData() == null) {
                    if (intent != null && intent.getClipData() != null) {
                        int count = intent.getClipData().getItemCount();
                        results = new Uri[count];
                        for (int i = 0; i < count; i++) {
                            results[i] = intent.getClipData().getItemAt(i).getUri();
                        }
                    }
                    if (mCM != null) {
                        File file = new File(Uri.parse(mCM).getPath());
                        if (file.length() > 0) results = new Uri[]{Uri.parse(mCM)};
                        else file.delete();
                    }
                    if (mVM != null) {
                        File file = new File(Uri.parse(mVM).getPath());
                        if (file.length() > 0) results = new Uri[]{Uri.parse(mVM)};
                        else file.delete();
                    }
                } else {
                    String dataString = intent.getDataString();
                    if (dataString != null) {
                        results = new Uri[]{Uri.parse(dataString)};
                    } else if (intent.getClipData() != null) {
                        int num = intent.getClipData().getItemCount();
                        results = new Uri[num];
                        for (int i = 0; i < num; i++) {
                            results[i] = intent.getClipData().getItemAt(i).getUri();
                        }
                    }
                }
            } else {
                if (mCM != null) {
                    File file = new File(Uri.parse(mCM).getPath());
                    if (file.exists()) file.delete();
                }
                if (mVM != null) {
                    File file = new File(Uri.parse(mVM).getPath());
                    if (file.exists()) file.delete();
                }
            }
            if (mUMA != null) {
                mUMA.onReceiveValue(results);
                mUMA = null;
            }
        } else if (requestCode == CODE_AUDIO_CHOOSER && resultCode == Activity.RESULT_OK) {
            Uri[] results = null;
            if (intent != null && intent.getData() != null) {
                results = new Uri[]{intent.getData()};
            }
            if (mUMA != null) {
                mUMA.onReceiveValue(results);
                mUMA = null;
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (windowContainer != null && windowContainer.getVisibility() == View.VISIBLE) {
            ClosePopupWindow(mWebviewPop);
        } else if (Config.EXIT_APP_BY_BACK_BUTTON_ALWAYS) {
            if (EXIT_APP_DIALOG) {
                ExitDialog();
            } else {
                super.onBackPressed();
            }
        } else if (webView != null && webView.canGoBack() && !isErrorPageLoaded) {
            webView.goBack();
        } else if (Config.EXIT_APP_BY_BACK_BUTTON_HOMEPAGE) {
            if (EXIT_APP_DIALOG) {
                ExitDialog();
            } else {
                super.onBackPressed();
            }
        }
    }

    @Override
    public void onPause() {
        if (webView != null) webView.onPause();
        super.onPause();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (webView != null) webView.onResume();
        if (Config.AUTO_REFRESH_ENABLED && webView != null) {
            webView.reload();
        }
    }

    @Override
    public void onStop() {
        if (Config.CLEAR_CACHE_ON_EXIT && webView != null) {
            webView.clearCache(true);
            CookieManager.getInstance().removeAllCookies(null);
            CookieManager.getInstance().flush();
        }
        super.onStop();
    }

    @Override
    public void onDestroy() {
        if (webView != null) {
            webView.destroy();
        }
        if (Config.CLEAR_CACHE_ON_EXIT) {
            CookieManager.getInstance().removeAllCookies(null);
            CookieManager.getInstance().flush();
        }
        super.onDestroy();
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        if (webView != null) webView.saveState(outState);
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        if (webView != null) webView.restoreState(savedInstanceState);
    }

    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (HIDE_NAVIGATION_BAR_IN_LANDSCAPE && newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            View decorView = getWindow().getDecorView();
            decorView.setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_IMMERSIVE
                            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_FULLSCREEN);
        }
    }

    private void webViewSetting(WebView intWebView) {
        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.setAcceptCookie(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            cookieManager.setAcceptThirdPartyCookies(intWebView, true);
        }

        WebSettings webSettings = intWebView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);
        webSettings.setAllowFileAccess(true);
        webSettings.setUseWideViewPort(true);
        webSettings.setLoadWithOverviewMode(true);
        webSettings.setAllowContentAccess(true);
        webSettings.setGeolocationEnabled(true);
        webSettings.setBuiltInZoomControls(false);
        webSettings.setSupportZoom(true);
        webSettings.setJavaScriptCanOpenWindowsAutomatically(true);
        webSettings.setCacheMode(WebSettings.LOAD_DEFAULT);

        intWebView.setLayoutParams(new RelativeLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        webSettings.setDatabaseEnabled(true);
        webSettings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        webSettings.setSupportMultipleWindows(true);

        if (!Config.USER_AGENT.isEmpty()) {
            webSettings.setUserAgentString(Config.USER_AGENT);
        }
    }

    // --- WebChromeClient ---
    private class MyWebChromeClient extends WebChromeClient {
        private final String appName;

        MyWebChromeClient(String appName) {
            this.appName = appName;
        }

        @Override
        public void onProgressChanged(WebView view, int progress) {
            if (ACTIVATE_PROGRESS_BAR) {
                if (progress < 100 && progressBar.getVisibility() == View.GONE) {
                    progressBar.setVisibility(View.VISIBLE);
                }
                progressBar.setProgress(progress);
                if (progress == 100) {
                    progressBar.setVisibility(View.GONE);
                }
            }
        }

        @Override
        public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
            callback.invoke(origin, true, false);
        }

        @Override
        public void onCloseWindow(WebView window) {
            super.onCloseWindow(window);
            ClosePopupWindow(mWebviewPop);
        }

        @Override
        public boolean onCreateWindow(WebView view, boolean dialog, boolean userGesture, Message resultMsg) {
            WebView.HitTestResult result = view.getHitTestResult();
            String data = result.getExtra();

            if (result.getType() == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE) {
                Message href = view.getHandler().obtainMessage();
                view.requestFocusNodeHref(href);
                data = href.getData().getString("url");
            }

            if (data != null && shouldAlwaysOpenInInappTab(data)) {
                openInInappTab(data);
                return true;
            }

            if (SPECIAL_LINK_HANDLING_OPTIONS == 0) {
                if (data == null || data.endsWith("#")) {
                    windowContainer.setVisibility(View.VISIBLE);
                    mWebviewPop = new WebView(view.getContext());
                    webViewSetting(mWebviewPop);
                    mWebviewPop.setWebChromeClient(new MyWebChromeClient(appName));
                    mWebviewPop.setWebViewClient(new MyWebViewClient());
                    mContainer.addView(mWebviewPop);

                    WebView.WebViewTransport transport = (WebView.WebViewTransport) resultMsg.obj;
                    transport.setWebView(mWebviewPop);
                    resultMsg.sendToTarget();
                    return true;
                } else if (URLUtil.isValidUrl(data)) {
                    webView.loadUrl(data);
                    return true;
                }
            } else if (SPECIAL_LINK_HANDLING_OPTIONS == 1) {
                if (data != null) {
                    openInInappTab(data);
                }
                return true;
            } else if (SPECIAL_LINK_HANDLING_OPTIONS == 2) {
                if (data != null) {
                    openInNewBrowser(data);
                }
                return true;
            }
            return true;
        }

        @Override
        public boolean onJsAlert(WebView view, String url, String message, final JsResult result) {
            new AlertDialog.Builder(view.getContext())
                    .setTitle(appName)
                    .setMessage(message)
                    .setPositiveButton("OK", (dialog, which) -> result.confirm())
                    .setOnCancelListener(dialog -> result.cancel())
                    .create()
                    .show();
            return true;
        }

        @Override
        public boolean onJsConfirm(WebView view, String url, String message, final JsResult result) {
            new AlertDialog.Builder(view.getContext())
                    .setTitle(appName)
                    .setMessage(message)
                    .setPositiveButton(android.R.string.ok, (dialog, which) -> result.confirm())
                    .setNegativeButton(android.R.string.cancel, (dialog, which) -> result.cancel())
                    .setOnCancelListener(dialog -> result.cancel())
                    .create()
                    .show();
            return true;
        }

        @Override
        public boolean onJsPrompt(WebView view, String url, String message, String defaultValue, JsPromptResult result) {
            final EditText input = new EditText(view.getContext());
            input.setInputType(InputType.TYPE_CLASS_TEXT);
            input.setText(defaultValue);
            new AlertDialog.Builder(view.getContext())
                    .setTitle(appName)
                    .setView(input)
                    .setMessage(message)
                    .setPositiveButton(android.R.string.ok, (dialog, which) -> result.confirm(input.getText().toString()))
                    .setNegativeButton(android.R.string.cancel, (dialog, which) -> result.cancel())
                    .setOnCancelListener(dialog -> result.cancel())
                    .create()
                    .show();
            return true;
        }

        @SuppressLint("InlinedApi")
        @Override
        public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback, FileChooserParams params) {
            mUMA = filePathCallback;
            fileChooserParams = params;

            boolean hasStorage = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU ||
                    ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
            boolean hasCamera = ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;

            if (hasStorage && hasCamera) {
                openFilePicker(params);
            } else {
                List<String> perms = new ArrayList<>();
                if (!hasCamera && Config.requireCamera) perms.add(Manifest.permission.CAMERA);
                if (!hasStorage && Config.requireStorage && Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
                    perms.add(Manifest.permission.READ_EXTERNAL_STORAGE);
                }
                if (!perms.isEmpty()) {
                    ActivityCompat.requestPermissions(MainActivity.this, perms.toArray(new String[0]), REQUEST_PERMISSION_STORAGE_CAMERA);
                } else {
                    openFilePicker(params);
                }
            }
            return true;
        }
    }

    // --- WebViewClient ---
    private class MyWebViewClient extends WebViewClient {

        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            customCSS();
            super.onPageStarted(view, url, favicon);
            if (ACTIVATE_PROGRESS_BAR) {
                progressBar.setVisibility(View.VISIBLE);
            }
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            customCSS();
            customJavaScript();
            if (ACTIVATE_PROGRESS_BAR) {
                progressBar.setVisibility(View.GONE);
            }
            if (mySwipeRefreshLayout != null) {
                mySwipeRefreshLayout.setRefreshing(false);
            }
        }

        @Override
        public void onReceivedError(WebView view, int errorCode, String description, String url) {
            if (Config.FALLBACK_USE_LOCAL_HTML_FOLDER_IF_OFFLINE) {
                loadLocal(INDEX_FILE);
                isErrorPageLoaded = true;
            } else {
                webView.setVisibility(View.GONE);
                offlineLayout.setVisibility(View.VISIBLE);
            }
        }

        @Override
        public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
            handler.cancel();
        }

        @Override
        public void onReceivedHttpAuthRequest(WebView view, HttpAuthHandler handler, String host, String realm) {
            Context ctx = view.getContext();
            LayoutInflater inflater = LayoutInflater.from(ctx);
            View dialogView = inflater.inflate(R.layout.activity_dialog_credentials, new LinearLayout(ctx));
            EditText username = dialogView.findViewById(R.id.username);
            EditText password = dialogView.findViewById(R.id.password);

            AlertDialog dialog = new AlertDialog.Builder(ctx)
                    .setView(dialogView)
                    .setTitle(R.string.auth_dialogtitle)
                    .setPositiveButton(R.string.submit, null)
                    .setNegativeButton(android.R.string.cancel, (d, w) -> handler.cancel())
                    .setOnDismissListener(d -> handler.cancel())
                    .create();
            dialog.show();

            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                if (TextUtils.isEmpty(username.getText())) {
                    username.setError(getResources().getString(R.string.user_name_required));
                } else if (TextUtils.isEmpty(password.getText())) {
                    password.setError(getResources().getString(R.string.password_name_required));
                } else {
                    handler.proceed(username.getText().toString(), password.getText().toString());
                    dialog.dismiss();
                }
            });
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            isErrorPageLoaded = false;

            if (url.startsWith("enablepulltorefresh://")) {
                if (mySwipeRefreshLayout != null) mySwipeRefreshLayout.setEnabled(true);
                return true;
            }
            if (url.startsWith("disablepulltorefresh://")) {
                if (mySwipeRefreshLayout != null) mySwipeRefreshLayout.setEnabled(false);
                return true;
            }

            // External intent schemes
            if (url.startsWith("tel:") || url.startsWith("sms:") || url.startsWith("mailto:")
                    || url.startsWith("whatsapp:") || url.startsWith("geo:")
                    || url.startsWith("market:") || url.startsWith("intent:")) {
                try {
                    Intent intent;
                    if (url.startsWith("intent:")) {
                        intent = Intent.parseUri(url, Intent.URI_INTENT_SCHEME);
                    } else {
                        intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    }
                    startActivity(intent);
                } catch (ActivityNotFoundException | java.net.URISyntaxException e) {
                    toast("Application not found to handle link.");
                }
                return true;
            }

            // File download check
            if (url.contains(".") && downloadableExtension.contains(url.substring(url.lastIndexOf(".")))) {
                downloadFile(url);
                return true;
            }

            // Whitelist check: always open in external browser
            for (String whiteUrl : Config.BROWSER_WHITELIST) {
                if (!whiteUrl.isEmpty() && url.contains(whiteUrl)) {
                    openInNewBrowser(url);
                    return true;
                }
            }

            // In-app tab check
            if (shouldAlwaysOpenInInappTab(url)) {
                openInInappTab(url);
                return true;
            }

            // External link handling
            if (URLisExternal(url)) {
                if (Config.EXTERNAL_LINK_HANDLING_OPTIONS == 1) {
                    openInInappTab(url);
                    return true;
                } else if (Config.EXTERNAL_LINK_HANDLING_OPTIONS == 2) {
                    openInNewBrowser(url);
                    return true;
                }
            }

            return false;
        }
    }

    // --- Gesture Detector for Swipe Navigation ---
    private class CustomeGestureDetector extends GestureDetector.SimpleOnGestureListener {
        @Override
        public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
            if (!ENABLE_SWIPE_NAVIGATE || e1 == null || e2 == null) return false;
            if (e1.getPointerCount() > 1 || e2.getPointerCount() > 1) return false;

            DisplayMetrics displayMetrics = new DisplayMetrics();
            getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
            int screenWidth = displayMetrics.widthPixels;
            int edgeSwipeTolerance = 30;

            try {
                // Left swipe from right edge -> forward
                if (e1.getX() - e2.getX() > 100 && Math.abs(velocityX) > 800) {
                    if (e1.getX() > (screenWidth - edgeSwipeTolerance)) {
                        if (webView.canGoForward()) {
                            webView.goForward();
                            return true;
                        }
                    }
                }
                // Right swipe from left edge -> back
                else if (e2.getX() - e1.getX() > 100 && Math.abs(velocityX) > 800) {
                    if (e1.getX() < edgeSwipeTolerance) {
                        if (webView.canGoBack()) {
                            webView.goBack();
                            return true;
                        }
                    }
                }
            } catch (Exception ignored) {
            }
            return false;
        }
    }
}
